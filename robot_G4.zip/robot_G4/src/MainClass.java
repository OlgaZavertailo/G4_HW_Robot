import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        String End_Game_Button = "L";
        System.out.println("Введте имя первого робота:");
        String robotAname = getLineFromConcole();
        Robot robot_A = new Robot(robotAname, End_Game_Button);
        System.out.println("You name:"+ robot_A.getRobotName());


        System.out.println("Введте имя второго робота:");
        String robotBname = getLineFromConcole();
        Robot robot_B = new Robot(robotBname, End_Game_Button);
        System.out.println("You name:"+ robot_B.getRobotName());

        while (robot_A.isAlive() || robot_B.isAlive()){
            System.out.printf("Кнопки которые принимают участие в игре: %s\n", robot_B.getAlphabet());
            System.out.printf("Для выхода с игры введите: %s\n",End_Game_Button);
            System.out.println("Введите кнопку для нанесения удара " + robot_B.getRobotName() + ":");
            String hitA = getLineFromConcole();
            if(hitA.equals(End_Game_Button)){
                System.out.println("Выход из игры!!!");
                break;
            }
            robot_B.hitMe(hitA);
            robot_A.printInfo();
            robot_B.printInfo();
            if (!robot_B.isAlive()){
                System.out.println("Победил робот:" + robot_A.getRobotName());
                break;
            }

            System.out.printf("Кнопки которые принимают участие в игре: %s\n", robot_A.getAlphabet());
            System.out.printf("Для выхода с игры введите: %s\n",End_Game_Button);
            System.out.println("Введите кнопку для нанесения удара " + robot_A.getRobotName() + ":");
            String hitB = getLineFromConcole();
            if(hitB.equals(End_Game_Button)){
                System.out.println("Выход из игры!!!");
                break;
            }
            robot_A.hitMe(hitB);
            robot_A.printInfo();
            robot_B.printInfo();
            if (!robot_A.isAlive()){
                System.out.println("Победил робот:" + robot_B.getRobotName());
                break;
            }
        }

    }
    public static String getLineFromConcole() {
        Scanner scanner = new Scanner(System.in); // умеет работать с системным вводом
            return scanner.nextLine();// считай цифру

    }
}
